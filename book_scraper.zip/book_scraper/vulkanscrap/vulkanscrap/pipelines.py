# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface

from itemadapter import ItemAdapter
import mysql.connector
from scrapy.exceptions import DropItem

class VulkanscrapPipeline:
    def open_spider(self, spider):
        self.connection = mysql.connector.connect(
            host='localhost',
            database='knjizarevulkan',
            user='root',
            password='psfvkL3:'
        )
        self.cursor = self.connection.cursor()

        self.cursor.execute("""DROP TABLE IF EXISTS knjige""")
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS knjige (
                isbn VARCHAR(20) PRIMARY KEY,
                naslov VARCHAR(255),
                autor VARCHAR(255),
                zanr VARCHAR(50),
                izdavac VARCHAR(50),
                godina INT,
                br_strana INT,
                povez VARCHAR(25),
                dimenzije VARCHAR(25),
                pismo VARCHAR(16),
                opis TEXT,
                cena DECIMAL(10, 2)
            )
        """)

    def close_spider(self, spider):
        self.connection.commit()
        self.cursor.close()
        self.connection.close()
        spider.logger.info("Database connection closed.")

    def process_item(self, item, spider):
        try:
            self.cursor.execute("""
                INSERT INTO knjige (isbn, naslov, autor, zanr, izdavac, godina, br_strana, povez, dimenzije, pismo, opis, cena)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (

                                item["isbn"],
                                item["naslov"],
                                item["autor"],
                                item["zanr"],
                                item["izdavac"],
                                item["godina"],
                                item["br_strana"],
                                item["povez"],
                                item["dimenzije"],
                                item["pismo"],
                                item["opis"],
                                item["cena"],


            ),
            )
            self.connection.commit()
        except mysql.connector.Error as e:
            self.connection.rollback()
            spider.logger.error(f"Error inserting item: {e} - Item: {item}")
            raise DropItem(f"Error inserting item: {e}")
        return item
