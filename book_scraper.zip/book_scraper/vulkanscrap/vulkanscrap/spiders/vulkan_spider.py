import scrapy
from ..items import VulkanscrapItem

class VulkanSpider(scrapy.Spider):
    name = 'vulkan_spider'
    start_urls = [

        f'https://www.knjizare-vulkan.rs/domace-knjige/page-{i}' for i in range(0, 1038)

        #'https://www.knjizare-vulkan.rs/domace-knjige/'
    ]

    '''
    for urls in start_urls:
            # this function directs to the exact pages that are going to be scraped and scrapes needed data from them
            def parse(self, response):
    
                books = response.css(".item-data")
    
                for book in books:
                    details_link = book.css(".product-link::attr(href)").get()
    
                    if details_link:
                        yield response.follow(details_link, callback=self.parse_detail)
                    else:
                        self.logger.info(f"Details link not found for the book linked: {details_link}")
    '''

    def parse(self, response):
        books = response.css(".item-data")

        for book in books:
            details_link = book.css(".product-link::attr(href)").get()

            if details_link:
                yield response.follow(details_link, callback=self.parse_detail)
            else:
                self.logger.info(f"Details link not found for the book linked: {details_link}")


    # the function takes care of each atrubute being scraped
    def parse_detail(self, response):

        self.logger.info(f"Parsing details from page: {response.url}")

        # these paths are defined by using SelectorGadget on browser and scrapy shell in termina/l

        isbn = response.css(".code .code span::text").get(default="") # isbn
        naslov = response.css(".block .product-details-info .title h1 span::text").get(
            default="N/A"
        )  # book title
        autor = (
            response.xpath("//tr[td[contains(text(), 'Autor')]]/td[2]/a/text()")
            .get(default="")
            .strip()
        ) # author
        zanr = (
            response.xpath("//tr[td[contains(text(), 'Kategorija')]]/td[2]/a/text()")
            .get(default="")
            .strip()
        ) # ganre
        izdavac = (
            response.xpath("//tr[td[contains(text(), 'Izdavač')]]/td[2]/a/text()")
            .get(default="")
            .strip()
        ) # publisher
        godina = (
            response.xpath("//tr[td[contains(text(), 'Godina')]]/td[2]/text()")
            .get(default="")
            .strip()
        ) # year
        br_strana = (
            response.xpath("//tr[td[contains(text(), 'Strana')]]/td[2]/text()")
            .get(default="-1")
            .strip()
        )
        br_strana = int(br_strana) if br_strana.isdigit() else -1 # no. pages
        povez = (
            response.xpath("//tr[td[contains(text(), 'Povez')]]/td[2]/text()")
            .get(default="")
            .strip()
        ) # binding
        dimenzije = (
            response.xpath("//tr[td[contains(text(), 'Format')]]/td[2]/text()")
            .get(default="")
            .strip()
        ) # format
        pismo = pismo = (
            response.css(".attr-pismo td+ td::text")
            .get(default="")
            .strip()
        ) # writting system
        opis = " ".join(
            response.css("#tab_product_description::text").getall()
        ).strip() # description
        cena = (
                response.css(".product-price-without-discount-value::text").get()
                or response.css(".product-price-value::text").get()
        )
        cena = float(cena.split(",")[0].replace(".", "")) if cena else 0.0#price

        item = VulkanscrapItem(
            isbn=isbn,
            naslov=naslov,
            autor=autor,
            zanr=zanr,
            izdavac=izdavac,
            godina=godina,
            br_strana=br_strana,
            povez=povez,
            dimenzije=dimenzije,
            pismo=pismo,
            opis=opis,
            cena=cena,
        )

        yield item