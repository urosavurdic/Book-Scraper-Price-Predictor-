# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class VulkanscrapItem(scrapy.Item):
    # define the fields for your item here like:
    isbn = scrapy.Field()  # isbn
    naslov = scrapy.Field()  # book title
    autor = scrapy.Field()  # author
    zanr = scrapy.Field()  # ganre
    izdavac = scrapy.Field()  # publisher
    godina = scrapy.Field()  # year
    br_strana = scrapy.Field()  # no. pages
    povez = scrapy.Field()  # binding
    dimenzije = scrapy.Field()  # format
    pismo = scrapy.Field()  # writting system
    opis = scrapy.Field()  # description
    cena = scrapy.Field()  # price

